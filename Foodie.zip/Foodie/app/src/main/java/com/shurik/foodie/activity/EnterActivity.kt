package com.shurik.foodie.activity

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.shurik.foodie.adapter.EnterPagerAdapter
import com.shurik.foodie.databinding.ActivityEnterBinding


class EnterActivity : AppCompatActivity() {
    var binding: ActivityEnterBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEnterBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        Thread {
            try {
                Thread.sleep(1500)
                runOnUiThread { binding!!.mainIcon.visibility = View.VISIBLE }
            } catch (e: InterruptedException) {
                throw RuntimeException(e)
            }
        }.start()
        binding!!.pager.adapter = EnterPagerAdapter(supportFragmentManager)
        binding!!.tabs.setupWithViewPager(binding!!.pager)
    }
}