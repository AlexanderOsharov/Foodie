package com.shurik.foodie.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.shurik.foodie.R


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}