package com.shurik.foodie.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.shurik.foodie.fragment.LoginFragment
import com.shurik.foodie.fragment.RegistrationFragment


class EnterPagerAdapter(fm: FragmentManager) :
    FragmentPagerAdapter(fm) {
    val fragments = arrayOfNulls<Fragment>(2)

    init {
        fragments[0] = LoginFragment()
        fragments[1] = RegistrationFragment()
    }

    override fun getItem(position: Int): Fragment {
        return fragments[position]!!
    }

    override fun getCount(): Int {
        return fragments.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return if (position == 0) "Авторизация" else "Регистрация"
    }
}
