package com.shurik.foodie.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.shurik.foodie.R
import android.content.Intent

import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast
import com.shurik.foodie.fragment.RegistrationFragment
import com.shurik.foodie.databinding.FragmentRegistrationBinding

import android.content.Context
import android.util.Log
import android.widget.Button

class RegistrationFragment : Fragment() {

    private lateinit var binding: FragmentRegistrationBinding
    private lateinit var firebaseAuth: FirebaseAuth

    @SuppressLint("ResourceType")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.e("aaaaaaaaaaaaaaa","aaaaaaaaaaaaaaaaaa")
        binding = FragmentRegistrationBinding.inflate(layoutInflater)
//        binding = FragmentRegistrationBinding.inflate<RegistrationFragment>(inflater!!, R.layout.fragment_registration , container , false )
        firebaseAuth = FirebaseAuth.getInstance()

        binding.signupButton.setOnClickListener{
            Log.e("ENTER","&&&&&&&&&&")
            val email = binding.signupEmail.text.toString()
            val password = binding.signupPassword.text.toString()
            val confirmPassword = binding.signupConfirm.text.toString()
            if (email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()){
                Log.e("Yes, successful","1")
                if (password == confirmPassword){
                    Log.e("Yes, successful","2")
                    firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener{
                        Log.e("Yes, successful","3")
                        if (it.isSuccessful){
                            Log.e("Yes, successful","4")
//                            val intent = Intent(this, LoginActivity::class.java)
//                            startActivity(intent)
//                            return inflater.inflate(R.layout.fragment_login, container, false)
                            // Get the FragmentManager and start a transaction.
                            val fragmentManager = activity?.supportFragmentManager
                            val fragmentTransaction = fragmentManager?.beginTransaction()

                            // Replace the contents of the container with the new fragment.
                            fragmentTransaction?.replace(R.layout.fragment_login, LoginFragment())
                            fragmentTransaction?.addToBackStack(null)
                            fragmentTransaction?.commit()
                        } else {
                            Toast.makeText(activity, it.exception.toString(), Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(activity, "Password does not matched", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(activity, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }
        binding.loginRedirectText.setOnClickListener {
            val fragmentManager = activity?.supportFragmentManager
            val fragmentTransaction = fragmentManager?.beginTransaction()

            // Replace the contents of the container with the new fragment.
            fragmentTransaction?.replace(R.layout.fragment_login, LoginFragment())
            fragmentTransaction?.addToBackStack(null)
            fragmentTransaction?.commit()
        }
        return inflater.inflate(R.layout.fragment_registration, container, false)
    }
}